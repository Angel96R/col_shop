class SiteClass:

    SITE_NAME = "Магазинчик Игр"

class PageClass:
    pass